﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriSecDBClientPanel.Helper
{
    class ETLSSessionIDStorage
    {
        public static String ETLSID { get; set; }
    }
}
