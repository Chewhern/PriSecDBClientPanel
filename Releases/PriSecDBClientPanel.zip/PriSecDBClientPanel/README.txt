Try to run the application's exe, if you can't run the application's exe, then try to run the setup in
this folder.

If you can't open the setup in this folder, then go to this link and install the required components.
https://dotnet.microsoft.com/download/dotnet-framework/net472
(Choose the RunApps RunTime with either web/offline installer).

Now the application is running in sandbox(PayPal), you will need to use these
sandbox credentials to mimic making payment.

Login Email: sb-vfpvt6618287@personal.example.com
Login Password: J/5Cv.j4